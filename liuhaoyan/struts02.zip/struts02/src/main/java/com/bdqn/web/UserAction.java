package com.bdqn.web;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {

    /*


    */

    public String login(){
        return SUCCESS;//是action的SUCCESS
    }

    public String register(){
        return SUCCESS;
    }

    public String update(){
        return SUCCESS;
    }

    public String delete(){
        return SUCCESS;
    }


}
